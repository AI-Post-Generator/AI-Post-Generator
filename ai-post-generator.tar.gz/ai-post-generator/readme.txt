=== AI Post Generator ===
Contributors: yourwordpressorgusername
Donate link: https://your-donation-link.com
Tags: ai, artificial intelligence, content generation, post generator, automatic posts, cohere, openai, gemini, blog automation, seo, content creation, auto post, automated content, content marketing, wordpress ai, ai writer
Requires at least: 5.6
Tested up to: 6.5
Requires PHP: 7.4
Stable tag: 1.5.2
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Unlock automated content creation for your WordPress site! AI Post Generator leverages leading AI models from Cohere, OpenAI (GPT), and Google Gemini to generate engaging blog posts, complete with keyword research, customizable categories, tags, and content length.

== Description ==

AI Post Generator is a powerful WordPress plugin designed to streamline your content creation process. By integrating with top-tier AI services—Cohere, OpenAI, and Google Gemini—this plugin automates the generation and publication of blog posts, saving you valuable time and effort.

Whether you need to maintain a consistent publishing schedule, explore new topic ideas, or simply augment your content strategy, AI Post Generator provides the tools to do so efficiently.

**Core Features:**

*   **Multiple AI Provider Support:** Seamlessly switch between Cohere, OpenAI (compatible with models like GPT-3.5-turbo, GPT-4, etc.), and Google Gemini to find the best fit for your content needs.
*   **Keyword-Driven Generation:** Input your desired keywords, and let the AI craft relevant titles and articles around them.
*   **Advanced Keyword Research (Optional):** Enable this feature to have the plugin perform an initial Google search (via Google Custom Search Engine API) based on your keyword and category context. It then intelligently selects a relevant search result title and uses AI to extract core English keywords from it. These highly focused keywords are then used to generate a more targeted and SEO-friendly post.
*   **Flexible Scheduling & Automation:**
    *   Set custom intervals for automatic post generation – from every few minutes (for rapid testing) to daily, weekly, or longer schedules.
    *   Define a "Cron Keyword" to guide the topic of regularly scheduled posts.
*   **Intelligent Categorization:**
    *   **Manual Selection:** Directly choose an existing category when generating a post manually.
    *   **Automatic Target Category (for Auto-Gen):** Set a preferred category in the plugin settings for all automatically generated posts. This overrides other auto-categorization methods.
    *   **Auto-Identify by Title:** If no specific category is chosen (manually or for auto-gen), the plugin attempts to match the AI-generated title to your existing WordPress category names.
    *   **Keyword-to-Category Mappings:** Create custom rules to assign posts to specific categories if their title or core subject (derived from input or research) contains certain keywords. This is a fallback if a specific category isn't set and auto-identification by title fails.
    *   **WordPress Default:** As a final fallback, posts are assigned to your WordPress installation's default category.
*   **Content & SEO Customization:**
    *   Control the approximate length of the generated content by setting maximum token limits.
    *   Automatically generate a list of SEO-friendly tags (in English) relevant to the post content.
*   **Post-Generation Enhancements:**
    *   **Internal Linking:** Automatically inserts 2-5 internal links within the generated content, pointing to existing posts or tag archive pages on your site to improve SEO and user engagement.
    *   **Featured Image:** Sets a random featured image for each new post (default uses placeholder image services, customizable via a WordPress filter).
*   **Author Control:** Assign a default WordPress user as the author for all AI-generated posts.
*   **User-Friendly Interface:** A clear and organized settings page within the WordPress admin area to manage API keys, select your active AI provider, configure keyword research, and fine-tune all generation preferences.

**Why Choose AI Post Generator?**

*   **Save Time:** Automate the repetitive task of writing initial drafts or generating content for regular updates.
*   **Increase Output:** Publish more frequently and consistently.
*   **Explore Topics:** Use the keyword research feature to discover and target relevant sub-topics.
*   **Improve SEO:** Benefit from auto-generated tags and internal linking.
*   **Versatile:** Adaptable to various content strategies and niches with its flexible settings.

**API Key Requirements (User-Provided):**

This plugin requires API keys from the AI services you intend to use. You are responsible for obtaining these keys and any costs associated with their usage from the respective providers.

*   **Cohere API Key:** Available from your Cohere Dashboard.
*   **OpenAI API Key:** Available from the OpenAI Platform (platform.openai.com).
*   **Google Gemini API Key:** Available from Google AI Studio (makersuite.google.com) for the Generative Language API.
*   **For the "Keyword Research" feature (optional):**
    *   **Google Custom Search Engine (CSE) API Key:** From Google Cloud Console.
    *   **Google Custom Search Engine ID (CX ID):** From Google's Programmable Search Engine control panel.

Detailed instructions for obtaining these keys are provided in the "Frequently Asked Questions" section.

== Installation ==

1.  **Upload Plugin:**
    *   Download the `ai-post-generator.zip` file.
    *   In your WordPress admin panel, go to "Plugins" > "Add New".
    *   Click "Upload Plugin" and choose the downloaded zip file.
    *   Alternatively, unzip the package and upload the `ai-post-generator` folder to your `/wp-content/plugins/` directory.
2.  **Activate Plugin:** Activate "AI Post Generator" through the 'Plugins' menu in WordPress.
3.  **Navigate to Settings:** A new menu item "AI Posts" will appear in your WordPress admin sidebar. Click on it to access the plugin settings.
4.  **Configure AI Provider Settings (Required):**
    *   Go to the "AI Provider" tab.
    *   Select your desired "Active AI Provider" (Cohere, OpenAI, or Google Gemini).
    *   Enter the corresponding API Key(s) and any model preferences (e.g., for OpenAI or Gemini).
    *   Click "Save AI Provider Settings".
5.  **Configure Keyword Research Settings (Optional but Recommended):**
    *   Go to the "Keyword Research" tab.
    *   If you wish to use this feature, check "Enable Keyword Research".
    *   Enter your "Google CSE API Key" and "Google CSE ID (cx)".
    *   Adjust the "Number of Search Titles to Analyze" if needed.
    *   Click "Save Keyword Research Settings".
6.  **Configure Automatic Generation Settings (Optional):**
    *   Go to the "Automatic Generation" tab.
    *   Check "Enable Auto Generation" to activate scheduled posting.
    *   Select a "Generation Interval".
    *   Optionally, enter a "Cron Initial Search Keyword" to guide topics for scheduled posts.
    *   Optionally, select a category under "Publish Auto-Posts to" if you want all automated posts to go to one specific category (this overrides mappings).
    *   Select a "Default Author" for all generated posts.
    *   Optionally, set up "Category Mappings" to assign posts to categories based on keywords in their title/subject (used if no specific auto-gen category is set and auto-identify by title fails).
    *   Adjust "Auto-Gen Content Length" if needed.
    *   Click "Save Automatic Generation Settings".
7.  **Manual Post Generation:**
    *   Go to the "Manual Generation" tab.
    *   Optionally, enter an "Initial Search Keyword" or "Keyword for Post".
    *   Optionally, select a "Publish to Category". If you choose "— Auto-Identify...", the plugin will try to find the best existing category.
    *   Optionally, set a "Content Length".
    *   Click "Generate & Publish Now".

== Frequently Asked Questions ==

= Which AI models are supported by the plugin? =
The plugin supports:
*   **Cohere:** Typically uses their `command` model.
*   **OpenAI:** You can specify models like `gpt-3.5-turbo`, `gpt-4`, `gpt-4-turbo-preview`, etc., in the settings.
*   **Google Gemini:** You can specify models like `gemini-1.5-flash-latest`, `gemini-pro`, etc., in the settings.
Ensure the model name you enter is compatible with the API key you are using.

= How do I obtain the necessary API keys? =
*   **Cohere API Key:** Sign up or log in at the [Cohere Platform](https://cohere.com/) and find your API key in your dashboard.
*   **OpenAI API Key:** Create an account or log in at [OpenAI Platform](https://platform.openai.com/) and generate an API key under your account settings.
*   **Google Gemini API Key:** Visit [Google AI Studio (Makersuite)](https://makersuite.google.com/app/apikey) and create an API key for the "Generative Language API".
*   **Google CSE API Key & CX ID (for Keyword Research):**
    1.  **API Key:** Go to the [Google Cloud Console](https://console.cloud.google.com/). Create a new project or select an existing one. Navigate to "APIs & Services" > "Library", search for "Custom Search API", and enable it. Then, go to "APIs & Services" > "Credentials" and create an API Key.
    2.  **CX ID (Search Engine ID):** Go to Google's [Programmable Search Engine control panel](https://programmablesearchengine.google.com/controlpanel/all). Click "Add" to create a new search engine. For "Sites to search," you can initially put a placeholder like `www.google.com`. After creation, edit the search engine and ensure under "Basics" > "Search settings", the option **"Search the entire web" is turned ON**. Then, copy the "Search engine ID" – this is your CX ID.

= Will using these AI services cost money? =
Yes, using the APIs from Cohere, OpenAI, and Google Gemini may incur costs depending on your usage volume. Each provider has its own pricing model and free tiers (if available). You are responsible for any charges associated with your API key usage. The Google Custom Search API also has free daily quotas, with charges for usage beyond that.

= How does the "Keyword Research" feature actually work? =
When enabled and an initial keyword is provided:
1.  The plugin takes your keyword (and optionally, a category context if available).
2.  It performs a Google search using the Google CSE API with this combined query.
3.  It fetches a set number of search result titles (e.g., top 5).
4.  It randomly selects one of these titles.
5.  It then uses the active AI provider to analyze this selected title and extract 2-4 of the most important and relevant keywords/keyphrases *in English*.
6.  These extracted English keywords then become the primary subject for generating the blog post title and content, aiming for a more focused and potentially better-ranking article.

= How is the category determined for newly generated posts? =
The logic is as follows:
1.  **Manual Generation (Specific Category Selected):** If you explicitly select a category from the dropdown on the "Manual Generation" page, the post will be published to that category.
2.  **Automatic Generation (Specific Target Category Set):** If you have selected a specific category in "Automatic Generation" settings under "Publish Auto-Posts to", all cron-generated posts will go to this category. This overrides other automatic methods.
3.  **Auto-Identify by Title (for Manual "Auto-Identify" or Cron without Target Category):** If no specific category is set as per above, the plugin will take the AI-generated post title and try to find a match with your existing WordPress category names. If a strong match is found (e.g., title contains a category name), that category is used.
4.  **Category Mappings:** If auto-identification by title fails, the plugin checks your "Category Mappings". If the post's core subject (from input keyword or research) or title contains a keyword you've mapped to a category, that category will be used.
5.  **WordPress Default Category:** If none of the above methods assign a category, the post will be assigned to the default category set in your main WordPress settings ("Settings" > "Writing").

= Can the plugin generate content in languages other than English? =
Currently, all AI prompts sent by the plugin are in English. The plugin is designed to primarily generate English titles, content, and tags. While the AI models themselves are multilingual and might understand non-English input keywords or produce non-English output if heavily prompted, consistent English output is the current focus for optimal results with the plugin's built-in prompts. If you input non-English keywords for research, the extracted keywords for generation will be translated to English by the AI.

= How can I customize the featured images? =
The plugin uses placeholder images from `picsum.photos` by default. You can provide your own list of image URLs by using the `ai_post_generator_featured_image_urls` WordPress filter in your theme's `functions.php` or a custom plugin.
Example:
`add_filter('ai_post_generator_featured_image_urls', function($default_urls) {`
`    return [`
`        'https://yourdomain.com/path/to/image1.jpg',`
`        'https://yourdomain.com/path/to/image2.png',`
`        // Add more URLs`
`    ];`
`});`

= What happens if an AI API call fails during generation? =
The plugin attempts to handle errors gracefully. API errors are typically logged (if `WP_DEBUG_LOG` is enabled in your `wp-config.php`). If an error occurs during generation (e.g., manual or cron), an admin notice might be displayed in the WordPress backend. If a critical step like content generation fails, the post creation process will likely be aborted for that attempt.

== Screenshots ==

(Leave this section as is for now. When you are ready to add screenshots to your plugin's assets on WordPress.org, you will list them here. For example:)
<!--
1.  The main settings page showing the "AI Provider" tab.
2.  Configuration options in the "Keyword Research" tab.
3.  The "Manual Generation" interface.
4.  Settings available in the "Automatic Generation" tab.
5.  Example of the "Category Mappings" section.
-->
Currently, screenshots are not included with the plugin package but will be available on the WordPress.org plugin page once submitted and approved.

== Changelog ==

= 1.5.2 =
*   FEATURE: Added "Publish Auto-Posts to Category" setting in Automatic Generation, allowing users to specify a target category for all cron-generated posts, which overrides mappings.
*   UPDATE: Removed the plugin-specific "Default Category" setting for automatic posts. Category assignment now cascades from specific selection -> auto-identify by title -> mappings -> WordPress core default category.
*   UPDATE: Changed display text for "Every 20 Seconds (Testing)" cron interval to "Every 20 Seconds".
*   ENHANCEMENT: Improved logic for deriving English context hints from category slugs for AI prompts.
*   ENHANCEMENT: All AI prompts are strictly in English to ensure consistent interaction with AI models.
*   GENERALIZATION: Updated AI prompt examples and placeholder texts in settings to be non-industry-specific and more universally applicable.
*   FIX: Refined author assignment logic to ensure a valid author is always used, with better fallbacks.
*   I18N: Updated translatable strings and POT file.

= 1.5.1 =
*   (Example: Enhanced AI prompts for "review" type categories to encourage selection of specific entities.)
*   (Example: Improved error logging for API calls.)

= 1.5.0 =
*   FEATURE: Added Search Engine Keyword Research capability (via Google CSE API) to refine topics based on real search data.
*   Added "Keyword Research" settings tab.
*   Updated AI prompts to utilize refined keywords from research.
*   UI updates on settings page.

= 1.4.0 =
*   FEATURE: Added support for Google Gemini AI provider and model selection.
*   Updated AI dispatcher and settings page for Gemini.

(It's good practice to keep a detailed changelog for every version.)

== Upgrade Notice ==

= 1.5.2 =
The plugin-specific "Default Category" setting under "Automatic Generation" has been removed. If you were relying on this, please now use the new "Publish Auto-Posts to Category" setting to specify a target category for all automated posts. If no target is set there, the plugin will attempt to auto-identify a category based on the generated title, then use category mappings, and finally fall back to your site's main WordPress default category.