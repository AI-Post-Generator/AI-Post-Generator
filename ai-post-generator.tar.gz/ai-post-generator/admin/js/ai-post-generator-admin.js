jQuery(document).ready(function($) {
    // aiPostGeneratorData is localized from PHP

    function activateTab(tabLinkEl) {
        var $tabLink = $(tabLinkEl);
        $('.nav-tab-wrapper a.nav-tab').removeClass('nav-tab-active');
        $tabLink.addClass('nav-tab-active');
        $('.tab-content').removeClass('active').hide();
        var targetTab = $tabLink.data('tab');
        $('#' + targetTab).addClass('active').show();

        if (window.history.pushState) {
            var newUrl = window.location.protocol + "//" + window.location.host + window.location.pathname + window.location.search + '#' + targetTab;
            window.history.pushState({path:newUrl},'',newUrl);
        } else {
            window.location.hash = targetTab;
        }
    }

    $('.nav-tab-wrapper a.nav-tab').on('click', function(e) {
        e.preventDefault();
        activateTab(this);
    });

    var hash = window.location.hash;
    if (hash) {
        var targetTabFromHash = hash.substring(1);
        var $tabLinkFromHash = $('.nav-tab-wrapper a.nav-tab[data-tab="' + targetTabFromHash + '"]');
        if ($tabLinkFromHash.length) {
            activateTab($tabLinkFromHash);
        } else {
            activateTab($('.nav-tab-wrapper a.nav-tab').first());
        }
    } else {
        activateTab($('.nav-tab-wrapper a.nav-tab').first());
    }

    $('#add-category-mapping').on('click', function() {
        var catOpts = '<option value="0">' + aiPostGeneratorData.select_category_text + '</option>';
        if (aiPostGeneratorData.categories && Array.isArray(aiPostGeneratorData.categories)) {
            aiPostGeneratorData.categories.forEach(function(cat) {
                catOpts += '<option value="' + cat.id + '">' + cat.name + '</option>';
            });
        }
        var newMapHTML = `<div class="category-mapping-item">
                            <input type="text" name="category_mappings_keyword[]" placeholder="${aiPostGeneratorData.keyword_placeholder_text}" class="regular-text" />
                            <select name="category_mappings_category_id[]">${catOpts}</select>
                            <button type="button" class="button remove-mapping">${aiPostGeneratorData.remove_text}</button>
                          </div>`;
        $('#category-mappings-container').append(newMapHTML);
    });

    $(document).on('click', '.remove-mapping', function() {
        $(this).closest('.category-mapping-item').remove();
    });
});