<?php
/**
 * Plugin Name:       AI Post Generator
 * Plugin URI:        https://github.com/AI-Post-Generator/AI-Post-Generator
 * Description:       Automatically generates and publishes blog posts using Cohere, OpenAI, or Google Gemini AI, with customizable categories, tags, content length, and search-engine-based keyword research.
 * Version:           1.5.2
 * Requires at least: 5.6
 * Requires PHP:      7.4
 * Author:            AI Post Generator
 * Author URI:        https://github.com/AI-Post-Generator/AI-Post-Generator
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       ai-post-generator
 * Domain Path:       /languages
 *
 * @package AI_Post_Generator
 */

// Ensure script runs within WordPress environment
if ( ! defined( 'ABSPATH' ) ) {
    die( 'This script must run within the WordPress environment!' );
}

// Define plugin constants
define( 'AI_POST_GENERATOR_VERSION', '1.5.2' ); // Removed _PRO
define( 'AI_POST_GENERATOR_PATH', plugin_dir_path( __FILE__ ) ); // Removed _PRO
define( 'AI_POST_GENERATOR_URL', plugin_dir_url( __FILE__ ) ); // Removed _PRO
define( 'AI_POST_GENERATOR_PLUGIN_FILE', __FILE__ ); // Removed _PRO

// Include the main plugin class
require_once AI_POST_GENERATOR_PATH . 'includes/class-ai-post-generator-plugin.php'; // Uses new constant

// Initialize the plugin
if ( class_exists( 'AI_Post_Generator_Plugin' ) ) { // Class name is already generic
    // Register activation, deactivation, and uninstall hooks
    register_activation_hook( AI_POST_GENERATOR_PLUGIN_FILE, array( 'AI_Post_Generator_Plugin', 'activate_static' ) ); // Uses new constant
    register_deactivation_hook( AI_POST_GENERATOR_PLUGIN_FILE, array( 'AI_Post_Generator_Plugin', 'deactivate_static' ) ); // Uses new constant
    register_uninstall_hook( AI_POST_GENERATOR_PLUGIN_FILE, array( 'AI_Post_Generator_Plugin', 'uninstall' ) ); // Uses new constant

    // Get the plugin instance and run it
    AI_Post_Generator_Plugin::get_instance();
}