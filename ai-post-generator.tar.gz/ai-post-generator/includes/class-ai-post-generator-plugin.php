<?php
/**
 * The core plugin class.
 *
 * @since      1.5.2
 * @package    AI_Post_Generator
 * @subpackage AI_Post_Generator/includes
 * @author     Your Name <youremail@example.com>
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

if ( ! class_exists( 'AI_Post_Generator_Plugin' ) ) {

    final class AI_Post_Generator_Plugin {

        const VERSION = AI_POST_GENERATOR_VERSION; // Uses new constant from main plugin file
        const TEXT_DOMAIN = 'ai-post-generator';

        // Option Names - No changes needed here as they were already generic
        const OPTION_COHERE_API_KEY = 'cohere_api_key';
        const OPTION_OPENAI_API_KEY = 'openai_api_key';
        const OPTION_OPENAI_MODEL = 'openai_model_name';
        const OPTION_GEMINI_API_KEY = 'gemini_api_key';
        const OPTION_GEMINI_MODEL = 'gemini_model_name';
        const OPTION_ACTIVE_AI_PROVIDER = 'ai_post_generator_active_provider';
        const OPTION_INTERVAL = 'ai_post_generate_interval';
        const OPTION_CRON_KEYWORD = 'ai_post_generator_cron_keyword';
        const OPTION_AUTO_GEN_TARGET_CATEGORY = 'ai_post_generator_auto_gen_target_category';
        const OPTION_DEFAULT_AUTHOR = 'ai_post_generator_default_author_id';
        const OPTION_CATEGORY_MAPPINGS = 'ai_post_generator_category_mappings';
        const OPTION_ENABLED = 'ai_post_generator_enabled';
        const OPTION_MAX_TOKENS_AUTO = 'ai_post_generator_max_tokens_auto';
        const OPTION_ENABLE_SEARCH_KEYWORD_RESEARCH = 'ai_post_generator_enable_search_keyword_research';
        const OPTION_GOOGLE_CSE_API_KEY = 'ai_post_generator_google_cse_api_key';
        const OPTION_GOOGLE_CSE_CX_ID = 'ai_post_generator_google_cse_cx_id';
        const OPTION_SEARCH_RESULTS_TO_CONSIDER = 'ai_post_generator_search_results_to_consider';

        const DEFAULT_MAX_TOKENS = 1500;
        const DEFAULT_SEARCH_RESULTS_TO_CONSIDER = 5;

        // API URLs and Timeouts (No changes needed here)
        const COHERE_API_URL = 'https://api.cohere.ai/v1/generate';
        const COHERE_API_TIMEOUT = 120;
        const OPENAI_API_URL = 'https://api.openai.com/v1/chat/completions';
        const OPENAI_API_TIMEOUT = 120;
        const GEMINI_API_BASE_URL = 'https://generativelanguage.googleapis.com/v1beta/models/';
        const GEMINI_API_TIMEOUT = 120;
        const DEFAULT_GEMINI_MODEL = 'gemini-1.5-flash-latest';
        const GOOGLE_CSE_API_URL = 'https://www.googleapis.com/customsearch/v1';
        const GOOGLE_CSE_API_TIMEOUT = 60;

        // Cron (No changes needed here)
        const CRON_EVENT_HOOK = 'ai_post_generator_cron_event';

        private static $instance;

        public static function get_instance() {
            if ( null === self::$instance ) {
                self::$instance = new self();
            }
            return self::$instance;
        }

        private function __construct() {
            $this->define_hooks();
        }

        private function define_hooks() {
            add_action( 'plugins_loaded', array( $this, 'load_textdomain' ) );
            add_action( 'admin_init', array( $this, 'settings_init' ) );
            add_action( 'admin_menu', array( $this, 'add_admin_menu' ) );
            add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_assets' ) );

            add_action( 'admin_post_ai_post_generator_save_api_settings', array( $this, 'handle_api_settings_submission' ) );
            add_action( 'admin_post_ai_post_generator_save_search_settings', array( $this, 'handle_search_settings_submission' ) );
            add_action( 'admin_post_ai_post_generator_save_auto_gen_settings', array( $this, 'handle_auto_gen_settings_submission' ) );
            add_action( 'admin_post_ai_post_generator_generate_now', array( $this, 'handle_manual_generation_submission' ) );

            add_action( self::CRON_EVENT_HOOK, array( $this, 'do_cron_job' ) );
            add_filter( 'cron_schedules', array( $this, 'add_cron_intervals' ) );
        }

        public function load_textdomain() {
            load_plugin_textdomain(
                self::TEXT_DOMAIN,
                false,
                dirname( plugin_basename( AI_POST_GENERATOR_PLUGIN_FILE ) ) . '/languages/' // Uses new constant
            );
        }

        public function enqueue_admin_assets( $hook_suffix ) {
            // menu_slug for add_menu_page is 'ai-post-generator'
            if ( 'toplevel_page_ai-post-generator' !== $hook_suffix ) {
                return;
            }
            wp_enqueue_style(
                self::TEXT_DOMAIN . '-admin-style',
                AI_POST_GENERATOR_URL . 'admin/css/ai-post-generator-admin.css', // Uses new constant
                array(),
                self::VERSION // This uses the class const VERSION, which refers to AI_POST_GENERATOR_VERSION
            );
            wp_enqueue_script(
                self::TEXT_DOMAIN . '-admin-script',
                AI_POST_GENERATOR_URL . 'admin/js/ai-post-generator-admin.js', // Uses new constant
                array( 'jquery' ),
                self::VERSION,
                true
            );
            $categories = get_categories( array( 'hide_empty' => 0, 'orderby' => 'name' ) );
            $js_data_for_admin_script = [
                'select_category_text' => esc_js(__('— Select Category —', self::TEXT_DOMAIN)),
                'keyword_placeholder_text' => esc_js(esc_attr__('Keyword', self::TEXT_DOMAIN)),
                'remove_text' => esc_js(__('Remove', self::TEXT_DOMAIN)),
                'categories' => array_values(array_map(function($cat){ return ['id' => $cat->term_id, 'name' => esc_js($cat->name)]; }, $categories))
            ];
            wp_localize_script( self::TEXT_DOMAIN . '-admin-script', 'aiPostGeneratorData', $js_data_for_admin_script );
        }

        private function _generate_with_cohere_api( $prompt, $max_tokens_requested ) {
            $apiKey = get_option( self::OPTION_COHERE_API_KEY ); if ( ! $apiKey ) { return new WP_Error('cohere_api_key_missing', esc_html__('Cohere API Key is not set.', self::TEXT_DOMAIN)); }
            $headers = ['Content-Type: application/json', 'Authorization: Bearer ' . $apiKey]; $data = json_encode( ['prompt' => $prompt, 'model' => 'command', 'max_tokens' => (int) $max_tokens_requested, 'temperature' => 0.7, 'k' => 0, 'stop_sequences' => [], 'return_likelihoods' => 'NONE', 'num_generations' => 1] );
            $ch = curl_init( self::COHERE_API_URL ); curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_HTTPHEADER => $headers, CURLOPT_POST => true, CURLOPT_POSTFIELDS => $data, CURLOPT_TIMEOUT => self::COHERE_API_TIMEOUT]);
            $response = curl_exec( $ch ); $http_code = curl_getinfo( $ch, CURLINFO_HTTP_CODE ); $curl_error = curl_error( $ch ); curl_close( $ch );
            if ( $curl_error ) { return new WP_Error('cohere_curl_error', sprintf(esc_html__('Error connecting to Cohere API: %s', self::TEXT_DOMAIN), $curl_error)); } $responseData = json_decode( $response, true );
            if ( $http_code !== 200 ) { $api_error_message = isset($responseData['message']) ? $responseData['message'] : esc_html(mb_substr($response, 0, 200)); return new WP_Error('cohere_api_response_error', sprintf(esc_html__('Cohere API Error: HTTP %d. Message: %s', self::TEXT_DOMAIN), $http_code, $api_error_message)); }
            if ( ! isset( $responseData['generations'][0]['text'] ) ) { return new WP_Error('cohere_api_format_error', esc_html__('Unexpected Cohere API response format.', self::TEXT_DOMAIN)); } return $responseData['generations'][0]['text'];
        }

        private function _generate_with_openai_api( $prompt, $max_tokens_requested, $system_message = null ) {
            $apiKey = get_option( self::OPTION_OPENAI_API_KEY ); $modelName = get_option( self::OPTION_OPENAI_MODEL, 'gpt-3.5-turbo' ); if ( ! $apiKey ) { return new WP_Error('openai_api_key_missing', esc_html__('OpenAI API Key is not set.', self::TEXT_DOMAIN)); }
            $headers = ['Content-Type: application/json', 'Authorization: Bearer ' . $apiKey]; $messages = []; if ($system_message) { $messages[] = ['role' => 'system', 'content' => $system_message]; } $messages[] = ['role' => 'user', 'content' => $prompt];
            $data = json_encode( ['model' => $modelName, 'messages' => $messages, 'max_tokens' => (int) $max_tokens_requested, 'temperature' => 0.4] );
            $ch = curl_init( self::OPENAI_API_URL ); curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_HTTPHEADER => $headers, CURLOPT_POST => true, CURLOPT_POSTFIELDS => $data, CURLOPT_TIMEOUT => self::OPENAI_API_TIMEOUT]);
            $response = curl_exec( $ch ); $http_code = curl_getinfo( $ch, CURLINFO_HTTP_CODE ); $curl_error = curl_error( $ch ); curl_close( $ch );
            if ( $curl_error ) { return new WP_Error('openai_curl_error', sprintf(esc_html__('Error connecting to OpenAI API: %s', self::TEXT_DOMAIN), $curl_error)); } $responseData = json_decode( $response, true );
            if ( $http_code !== 200 ) { $error_message_from_api = isset($responseData['error']['message']) ? $responseData['error']['message'] : esc_html(mb_substr($response, 0, 200)); return new WP_Error('openai_api_response_error', sprintf(esc_html__('OpenAI API Error: HTTP %d. Message: %s', self::TEXT_DOMAIN), $http_code, $error_message_from_api)); }
            if ( ! isset( $responseData['choices'][0]['message']['content'] ) ) { return new WP_Error('openai_api_format_error', esc_html__('Unexpected OpenAI API response format.', self::TEXT_DOMAIN)); } return trim($responseData['choices'][0]['message']['content']);
        }

        private function _generate_with_gemini_api( $prompt, $max_tokens_requested, $system_message = null ) {
            $apiKey = get_option( self::OPTION_GEMINI_API_KEY ); $modelName = get_option( self::OPTION_GEMINI_MODEL, self::DEFAULT_GEMINI_MODEL ); if ( ! $apiKey ) { return new WP_Error('gemini_api_key_missing', esc_html__('Google Gemini API Key is not set.', self::TEXT_DOMAIN));}
            $apiUrl = self::GEMINI_API_BASE_URL . $modelName . ':generateContent?key=' . $apiKey; $headers = ['Content-Type: application/json']; $full_prompt_parts = []; $full_prompt_parts[] = ['text' => ($system_message ? $system_message . "\n\nUser Prompt:\n" : "") . $prompt];
            $payload = ['contents' => [['role' => 'user', 'parts' => $full_prompt_parts]], 'generationConfig' => ['maxOutputTokens' => (int) $max_tokens_requested, 'temperature' => 0.4]];
            $data = json_encode($payload); $ch = curl_init( $apiUrl ); curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_HTTPHEADER => $headers, CURLOPT_POST => true, CURLOPT_POSTFIELDS => $data, CURLOPT_TIMEOUT => self::GEMINI_API_TIMEOUT]);
            $response = curl_exec( $ch ); $http_code = curl_getinfo( $ch, CURLINFO_HTTP_CODE ); $curl_error = curl_error( $ch ); curl_close( $ch );
            if ( $curl_error ) { return new WP_Error('gemini_curl_error', sprintf(esc_html__('Error connecting to Google Gemini API: %s', self::TEXT_DOMAIN), $curl_error)); } $responseData = json_decode( $response, true );
            if ( $http_code !== 200 ) { $error_message_from_api = isset($responseData['error']['message']) ? $responseData['error']['message'] : (isset($responseData['message']) ? $responseData['message'] : esc_html(mb_substr($response, 0, 200))); return new WP_Error('gemini_api_response_error', sprintf(esc_html__('Google Gemini API Error: HTTP %d. Message: %s', self::TEXT_DOMAIN), $http_code, $error_message_from_api)); }
            if ( ! isset( $responseData['candidates'][0]['content']['parts'][0]['text'] ) ) { error_log("❌ AI Post Generator (Gemini): Unexpected API response format. Full Response: " . print_r($responseData, true)); return new WP_Error('gemini_api_format_error', esc_html__('Unexpected Google Gemini API response format.', self::TEXT_DOMAIN)); } return trim($responseData['candidates'][0]['content']['parts'][0]['text']);
        }

        private function _fetch_search_results_from_google_cse( $query, $num_results = 5 ) {
            $api_key = get_option( self::OPTION_GOOGLE_CSE_API_KEY ); $cx_id = get_option( self::OPTION_GOOGLE_CSE_CX_ID ); if ( ! $api_key || ! $cx_id ) { error_log( "❌ AI Post Generator (Search): Google CSE API Key or CX ID is not set." ); return new WP_Error( 'google_cse_missing_creds', esc_html__( 'Google CSE API Key or CX ID not configured.', self::TEXT_DOMAIN ) ); }
            $url = add_query_arg( ['key' => $api_key, 'cx'  => $cx_id, 'q'   => rawurlencode( $query ), 'num' => max(1, min(10, (int) $num_results ))], self::GOOGLE_CSE_API_URL );
            $response = wp_remote_get( $url, ['timeout' => self::GOOGLE_CSE_API_TIMEOUT] ); if ( is_wp_error( $response ) ) { error_log( "❌ AI Post Generator (Search): Error fetching Google CSE results for '{$query}': " . $response->get_error_message() ); return $response; }
            $body = wp_remote_retrieve_body( $response ); $data = json_decode( $body, true ); $http_code = wp_remote_retrieve_response_code( $response );
            if ( $http_code !== 200 ) { $error_message = isset( $data['error']['message'] ) ? $data['error']['message'] : esc_html__( 'Unknown API error', self::TEXT_DOMAIN ); error_log( "❌ AI Post Generator (Search): Google CSE API Error HTTP {$http_code} for '{$query}': {$error_message}" ); return new WP_Error( 'google_cse_api_error', sprintf( esc_html__( 'Google CSE API Error (HTTP %d): %s', self::TEXT_DOMAIN ), $http_code, $error_message ) ); }
            if ( ! isset( $data['items'] ) || empty( $data['items'] ) ) { error_log( "ℹ️ AI Post Generator (Search): No search results from Google CSE for '{$query}'." ); return new WP_Error( 'google_cse_no_results', esc_html__( 'No search results for query.', self::TEXT_DOMAIN ) ); }
            $titles = []; foreach ( $data['items'] as $item ) { if ( isset( $item['title'] ) && ! empty( trim( $item['title'] ) ) ) { $titles[] = sanitize_text_field( $item['title'] ); } }
            if (empty($titles)) { error_log( "ℹ️ AI Post Generator (Search): No usable titles from Google CSE for '{$query}'." ); return new WP_Error( 'google_cse_no_titles', esc_html__( 'No usable titles in search results.', self::TEXT_DOMAIN ) ); }
            error_log( "✅ AI Post Generator (Search): Fetched " . count($titles) . " titles for query '{$query}'." ); return $titles;
        }

        public function generate_ai_text( $prompt, $show_output_on_error = false, $max_tokens_param = 500, $purpose = 'content' ) {
            $active_provider = get_option( self::OPTION_ACTIVE_AI_PROVIDER, 'cohere' ); $result_text = false; $error_object = null; $system_message_for_provider = null;
            $common_system_messages = [
                'title' => "You are an expert blog title writer. Your goal is to generate a concise and engaging blog post title based on the user's request. Enclose the main subject or the primary title phrase in double quotes for easy extraction. Example: \"The Ultimate Guide to Remote Work\" or \"Mastering Content Creation for Beginners\". Ensure the title is unique and not generic.",
                'tags' => "You are an SEO expert. Your task is to generate 5-8 relevant, comma-separated SEO-friendly tags for a blog post based on the user's request. Tags should be concise, lowercase, and can include multi-word phrases. Examples: 'digital marketing, productivity hacks, online tools, content strategy, software tips'. Do not include any other text, numbering, or quotation marks around the tags themselves.",
                'content' => "You are a skilled blog post writer. Your task is to write a comprehensive, engaging, and SEO-friendly blog post based on the provided title and subject. Structure the post with an introduction, several main body paragraphs, and a conclusion. Use examples, explanations, and lists where appropriate. Maintain a professional yet accessible tone. Avoid overly repetitive phrases. Do not use HTML for formatting, just plain text with standard paragraph breaks.",
                'extract_keywords_from_title' => "You are an SEO and content strategy expert. The primary user query is '[USER_QUERY_PLACEHOLDER]'. The desired context is '[CONTEXT_HINT_PLACEHOLDER]'. Now, analyze the following blog post title found from a search: \"[SELECTED_TITLE_PLACEHOLDER]\". From this title, extract ONLY the 2-3 keywords or key phrases that are MOST DIRECTLY relevant to BOTH the primary user query AND the desired context. Discard any keywords that are only loosely related or secondary. Return the keywords as a comma-separated list, in English. If the original keywords in the title are not in English, translate them to English. Do not include any other explanatory text, just the English keywords. Example: User query 'email marketing', context 'software comparison', title 'Top 10 Email Marketing Platforms for 2024', return 'email marketing platforms, top email software, 2024 marketing tools'.",
            ];
            if ($purpose === 'extract_keywords_from_title' && is_array($prompt)) { $system_message_for_purpose = str_replace(['[USER_QUERY_PLACEHOLDER]', '[CONTEXT_HINT_PLACEHOLDER]', '[SELECTED_TITLE_PLACEHOLDER]'], [$prompt['user_query'], $prompt['context_hint'], $prompt['selected_title']], $common_system_messages[$purpose]); $prompt = "Proceed with keyword extraction based on system instructions and title provided therein."; }
            else { $system_message_for_purpose = $common_system_messages[$purpose] ?? null; }
            $api_key_option_name = ''; switch ($active_provider) { case 'openai': $api_key_option_name = self::OPTION_OPENAI_API_KEY; break; case 'gemini': $api_key_option_name = self::OPTION_GEMINI_API_KEY; break; default: $api_key_option_name = self::OPTION_COHERE_API_KEY; break; }
            if ( ! get_option( $api_key_option_name ) ) { $error_object = new WP_Error($active_provider.'_api_key_missing', sprintf(esc_html__('%s API Key is not set.', self::TEXT_DOMAIN ), ucfirst($active_provider))); }
            else { switch ( $active_provider ) { case 'openai': $response = $this->_generate_with_openai_api( $prompt, $max_tokens_param, $system_message_for_purpose ); if (is_wp_error($response)) { $error_object = $response; } else { $result_text = $response; } break; case 'gemini': $response = $this->_generate_with_gemini_api( $prompt, $max_tokens_param, $system_message_for_purpose ); if (is_wp_error($response)) { $error_object = $response; } else { $result_text = $response; } break; default: $full_prompt_for_cohere = $system_message_for_purpose ? $system_message_for_purpose . "\n\nUser Prompt:\n" . $prompt : $prompt; $response = $this->_generate_with_cohere_api( $full_prompt_for_cohere, $max_tokens_param ); if (is_wp_error($response)) { $error_object = $response; } else { $result_text = $response; } break; } }
            if ($error_object) { error_log(sprintf("❌ AI Post Generator (%s - Purpose: %s): %s - %s. Prompt: %s", strtoupper($active_provider), $purpose, $error_object->get_error_code(), $error_object->get_error_message(), (is_array($prompt) ? json_encode($prompt) : mb_substr($prompt, 0, 350)) )); if ( is_admin() && $show_output_on_error ) { add_settings_error('ai-post-generator', $error_object->get_error_code(), sprintf( esc_html__( 'AI Generation Error (%1$s - Purpose: %2$s): %3$s', self::TEXT_DOMAIN ), strtoupper($active_provider), ucfirst($purpose), $error_object->get_error_message() ), 'error'); } }
            return $result_text;
        }

        private function _get_refined_keywords_via_search_research( $initial_keyword_query, $context_hint_for_ai = '' ) {
            error_log("ℹ️ AI Post Generator: Starting keyword research. Initial query: '{$initial_keyword_query}', AI Context hint: '{$context_hint_for_ai}'");
            $num_results_to_consider = get_option( self::OPTION_SEARCH_RESULTS_TO_CONSIDER, self::DEFAULT_SEARCH_RESULTS_TO_CONSIDER ); $search_query = trim($initial_keyword_query);
            if (!empty(trim($context_hint_for_ai))) { $context_hint_trimmed = trim($context_hint_for_ai); if (stripos($search_query, $context_hint_trimmed) === false) { $search_query = $search_query . ' ' . $context_hint_trimmed; } }
            error_log("ℹ️ AI Post Generator: Using search query: '{$search_query}'"); $search_titles = $this->_fetch_search_results_from_google_cse( $search_query, $num_results_to_consider );
            if ( is_wp_error( $search_titles ) ) { error_log("⚠️ AI Post Generator: Search research failed for '{$search_query}': " . $search_titles->get_error_message()); if (is_admin()) add_settings_error('ai-post-generator', 'search_research_failed', sprintf(esc_html__('Keyword research for query "%1$s" failed: %2$s.', self::TEXT_DOMAIN), esc_html($search_query), $search_titles->get_error_message()), 'warning'); return false; }
            if ( empty( $search_titles ) ) { error_log("⚠️ AI Post Generator: No titles from search for '{$search_query}'."); if (is_admin()) add_settings_error('ai-post-generator', 'search_no_titles', sprintf(esc_html__('No titles found for query "%s".', self::TEXT_DOMAIN), esc_html($search_query)), 'warning'); return false; }
            $selected_title = $search_titles[ array_rand( $search_titles ) ]; error_log("ℹ️ AI Post Generator: Randomly selected title for keyword extraction: '{$selected_title}'");
            $prompt_data_for_extraction = ['user_query' => $initial_keyword_query, 'context_hint' => $context_hint_for_ai, 'selected_title' => $selected_title];
            $extracted_keywords_string = $this->generate_ai_text( $prompt_data_for_extraction, true, 150, 'extract_keywords_from_title' );
            if ( ! $extracted_keywords_string || is_wp_error( $extracted_keywords_string ) ) { error_log("⚠️ AI Post Generator: Failed to extract keywords from title '{$selected_title}'."); if (is_admin()) add_settings_error('ai-post-generator', 'keyword_extraction_failed_en', sprintf(esc_html__('AI failed to extract English keywords from title ("%1$s").', self::TEXT_DOMAIN), esc_html($selected_title)), 'warning'); return false; }
            $extracted_keywords_string = trim( $extracted_keywords_string, ". \t\n\r\0\x0B\"'" ); $refined_keywords_array = array_map( 'trim', explode( ',', $extracted_keywords_string ) );
            $refined_keywords_array = array_filter( $refined_keywords_array, function($kw) { return !empty($kw) && strlen($kw) > 2 && preg_match('/^[a-zA-Z0-9\s,-]+$/', $kw); } );
            if ( empty( $refined_keywords_array ) ) { error_log("⚠️ AI Post Generator: AI returned empty/invalid English keywords for '{$selected_title}'. Raw: '{$extracted_keywords_string}'."); if (is_admin()) add_settings_error('ai-post-generator', 'empty_extracted_keywords_en', sprintf(esc_html__('AI returned no usable English keywords from title ("%1$s"). Raw: "%2$s".', self::TEXT_DOMAIN), esc_html($selected_title), esc_html($extracted_keywords_string)), 'warning'); return false; }
            $final_refined_keyword_string = implode( ', ', $refined_keywords_array ); error_log("✅ AI Post Generator: Refined English keywords: '{$final_refined_keyword_string}' from title '{$selected_title}'");
            if (is_admin()) add_settings_error('ai-post-generator', 'keywords_refined_en', sprintf(esc_html__('Refined English keywords: "%1$s" (from title: "%2$s", context: "%3$s").', self::TEXT_DOMAIN), esc_html($final_refined_keyword_string), esc_html($selected_title), esc_html($context_hint_for_ai)), 'info');
            return $final_refined_keyword_string;
        }

        public function generate_ai_title( $prompt ) { return $this->generate_ai_text( $prompt, true, 70, 'title' ); }
        public function generate_ai_tags( $prompt ) {
            $raw_tags_output = $this->generate_ai_text( $prompt, true, 100, 'tags' ); if ( ! $raw_tags_output ) return false;
            $tags_string = trim( preg_replace( ['/\n|\r/', '/^["\'\s]*|["\'\s]*$/', '/\s*,\s*/'], [',', '', ','], $raw_tags_output ) );
            $tags_array = array_map(fn($tag) => trim($tag, " \t\n\r\0\x0B"), explode( ',', $tags_string )); $cleaned_tags = [];
            foreach ( $tags_array as $tag ) { $cleaned_tag = sanitize_text_field( trim( $tag ) ); if ( !empty($cleaned_tag) && mb_strlen($cleaned_tag) > 1 && mb_strlen($cleaned_tag) <= 100 && preg_match('/^[a-zA-Z0-9\s-]+$/', $cleaned_tag) ) { $cleaned_tag = rtrim($cleaned_tag, ',.'); if (!empty($cleaned_tag) && mb_strlen($cleaned_tag) > 1) { $cleaned_tags[] = $cleaned_tag; } } }
            return array_unique( $cleaned_tags );
        }
        public function extract_quoted_title( $text ) {
            $best_title = ''; $max_word_count = 0; if ( preg_match_all( '/"([^"]+)"/', $text, $matches ) ) { foreach ( $matches[1] as $quoted_string ) { if (str_word_count($quoted_string) > $max_word_count && str_word_count($quoted_string) < 20) { $max_word_count = str_word_count($quoted_string); $best_title = $quoted_string; } } }
            if ( empty($best_title) ) { $lines = explode("\n", $text); $first_line = trim(preg_replace('/^(Blog Post Title:|Title:)\s*/i', '', $lines[0])); $cleaned_text = trim(preg_replace(['/\n|\r/', '/\s+/', '/^["\']|["\']$/'], [' ', ' ', ''], $first_line)); if (str_word_count($cleaned_text) < 3 && count($lines) > 1) { $more_text = trim(preg_replace('/^(Blog Post Title:|Title:)\s*/i', '', implode(" ", array_slice($lines, 0, 3)))); $cleaned_text = trim(preg_replace(['/\n|\r/', '/\s+/', '/^["\']|["\']$/'], [' ', ' ', ''], $more_text)); } if (str_word_count($cleaned_text) < 2) { $cleaned_text = trim(preg_replace(['/\n|\r/', '/\s+/', '/^["\']|["\']$/', '/^(Blog Post Title:|Title:)\s*/i'], [' ', ' ', '', ''], $text)); } return sanitize_text_field(trim($cleaned_text)); }
            return sanitize_text_field(trim($best_title));
        }
        public function insert_internal_links( $content, $current_post_id = 0, $current_post_tags_names = array() ) {
             $links_inserted_count = 0; $max_links = rand( 2, 5 ); $potential_links = []; $linked_keyword_texts_lower = [];
            $post_args = ['post_type' => 'post', 'post_status' => 'publish', 'posts_per_page' => 150, 'orderby' => 'rand', 'exclude' => $current_post_id ? array( $current_post_id ) : [], 'no_found_rows' => true, 'fields' => 'ids']; $other_post_ids = get_posts( $post_args );
            foreach ( $other_post_ids as $p_id ) { $title = wp_strip_all_tags( get_the_title( $p_id ) ); if ( ! empty( $title ) && mb_strlen( $title ) > 5 && str_word_count($title) > 1 ) $potential_links[] = ['keyword_text' => $title, 'url' => get_permalink( $p_id ), 'type' => 'post'];}
            if ( ! empty( $current_post_tags_names ) ) { foreach ( $current_post_tags_names as $tag_name ) { $cleaned_tag_name = wp_strip_all_tags( $tag_name ); $tag = get_term_by( 'name', $cleaned_tag_name, 'post_tag' ); if ( $tag && ! is_wp_error( $tag ) && mb_strlen( $cleaned_tag_name ) > 3 ) $potential_links[] = ['keyword_text' => $cleaned_tag_name, 'url' => get_tag_link( $tag->term_id ), 'type' => 'tag']; } }
            shuffle( $potential_links ); $unique_potential_links = []; $seen_keywords_for_potential = []; foreach ($potential_links as $link) { $keyword_lower_for_potential = strtolower($link['keyword_text']); if (!in_array($keyword_lower_for_potential, $seen_keywords_for_potential)) { $unique_potential_links[] = $link; $seen_keywords_for_potential[] = $keyword_lower_for_potential; } }
            $potential_links = $unique_potential_links; if (empty($potential_links)) return $content;
            $content_parts = preg_split( '/(<[^>]+>)/i', $content, -1, PREG_SPLIT_DELIM_CAPTURE | PREG_SPLIT_NO_EMPTY ); $new_content = ''; $is_inside_a_tag = false;
            foreach ( $content_parts as $part ) { if (preg_match('/^<.*>$/s', $part)) { if (preg_match('/^<a\s/i', $part)) $is_inside_a_tag = true; if (preg_match('/^<\/a>/i', $part)) $is_inside_a_tag = false; $new_content .= $part; continue; }
                if (!$is_inside_a_tag) { $text_to_process = $part; foreach ( array('post', 'tag') as $link_type_priority ) { foreach ( $potential_links as $link_info ) { if ( $links_inserted_count >= $max_links ) break 3; if ( $link_info['type'] !== $link_type_priority ) continue; $keyword_text_clean = $link_info['keyword_text']; $keyword_text_lower = strtolower( $keyword_text_clean ); if ( in_array( $keyword_text_lower, $linked_keyword_texts_lower ) ) continue; if (mb_stripos($content, 'href="' . get_permalink($current_post_id)) !== false && mb_stripos($keyword_text_clean, get_the_title($current_post_id)) !== false) continue; $pattern = '/\b(' . preg_quote( $keyword_text_clean, '/' ) . ')\b/iu'; $replace_count = 0; $text_to_process = preg_replace( $pattern, '<a href="' . esc_url( $link_info['url'] ) . '" title="'.esc_attr($keyword_text_clean).'">$1</a>', $text_to_process, 1, $replace_count ); if ($replace_count > 0) { $linked_keyword_texts_lower[] = $keyword_text_lower; $links_inserted_count++; error_log( "✅ AI Post Generator: Inserted " . strtoupper($link_info['type']) . " link for '{$keyword_text_clean}'. Count: {$links_inserted_count}" ); if ( $links_inserted_count >= $max_links ) break 3;} } } $new_content .= $text_to_process;
                } else { $new_content .= $part; } }
            return $new_content;
        }
        public function set_random_featured_image( $post_id ) {
            $image_urls = apply_filters('ai_post_generator_featured_image_urls', array( 'https://picsum.photos/1200/800?random=' . rand(1, 100), 'https://picsum.photos/1200/800?random=' . rand(101, 200), )); if (empty($image_urls)) return false; $random_image_url = $image_urls[ array_rand( $image_urls ) ]; error_log( "ℹ️ AI Post Generator: Attempting to set featured image for post ID {$post_id} from URL: {$random_image_url}" );
            if ( ! function_exists( 'media_handle_sideload' ) ) { require_once( ABSPATH . 'wp-admin/includes/image.php' ); require_once( ABSPATH . 'wp-admin/includes/file.php' ); require_once( ABSPATH . 'wp-admin/includes/media.php' ); } $tmp = download_url( $random_image_url, 30 ); if ( is_wp_error( $tmp ) ) { error_log( "❌ AI Post Generator: Failed to download image. Error: " . $tmp->get_error_message() ); return false; }
            $file_array = ['name' => sanitize_file_name( 'ai-post-' . $post_id . '-featured-' . time() . '-' . wp_rand(100,999) . '.jpg' ), 'tmp_name' => $tmp]; $attach_id = media_handle_sideload( $file_array, $post_id, esc_html__( 'AI Generated Featured Image', self::TEXT_DOMAIN ) );
            if ( is_wp_error( $attach_id ) ) { @unlink( $file_array['tmp_name'] ); error_log( "❌ AI Post Generator: Failed to sideload image. Error: " . $attach_id->get_error_message() ); return false; } if ( set_post_thumbnail( $post_id, $attach_id ) ) { error_log( "✅ AI Post Generator: Successfully set featured image (ID: {$attach_id}) for post ID {$post_id}" ); return $attach_id; }
            error_log( "❌ AI Post Generator: Sideload ok (ID: {$attach_id}), but set_post_thumbnail failed for post ID {$post_id}." ); return false;
        }

        public function generate_and_publish_post( $initial_keyword_or_search_query = '', $category_id_from_manual_selection = 0, $manual_max_tokens = null ) {
            $active_provider = get_option( self::OPTION_ACTIVE_AI_PROVIDER, 'cohere' );
            $provider_api_key_const_name = 'self::OPTION_' . strtoupper($active_provider) . '_API_KEY';
            if (defined($provider_api_key_const_name)) { $api_key_option_name = constant($provider_api_key_const_name); }
            else { if (is_admin()) add_settings_error('ai-post-generator', 'internal_error_provider_key_const', esc_html__('Internal error: API key constant not found.', self::TEXT_DOMAIN ), 'error' ); return new WP_Error( 'internal_error_provider_key_const', esc_html__('Internal error: API key constant not found.', self::TEXT_DOMAIN ) ); }
            if ( ! get_option( $api_key_option_name ) ) { if (is_admin()) add_settings_error('ai-post-generator', $active_provider . '_api_key_missing', sprintf(esc_html__('%s API Key is not set.', self::TEXT_DOMAIN), ucfirst($active_provider)), 'error'); return new WP_Error($active_provider . '_api_key_missing', sprintf(esc_html__('%s API Key is not set.', self::TEXT_DOMAIN), ucfirst($active_provider))); }

            $post_author_id = 0; $configured_default_author_id = get_option( self::OPTION_DEFAULT_AUTHOR );
            if ( $configured_default_author_id && $configured_default_author_id > 0 ) { if ( get_user_by( 'ID', $configured_default_author_id ) ) { $post_author_id = $configured_default_author_id; error_log("ℹ️ AI Post Generator: Using configured default author ID: {$post_author_id}"); } else { error_log("⚠️ AI Post Generator: Configured default author ID {$configured_default_author_id} is invalid."); if (is_admin()) add_settings_error('ai-post-generator', 'author-invalid', sprintf(esc_html__('Configured default author (ID: %d) is invalid.',self::TEXT_DOMAIN), $configured_default_author_id ), 'warning'); } }
            if ( $post_author_id === 0 ) { if ( is_user_logged_in() && current_user_can( 'publish_posts' ) ) { $post_author_id = get_current_user_id(); error_log("ℹ️ AI Post Generator: Using current logged-in user ID: {$post_author_id}"); } else { $admin_users = get_users( array( 'role' => 'administrator', 'number' => 1, 'orderby' => 'ID' ) ); if ( ! empty( $admin_users ) ) { $post_author_id = $admin_users[0]->ID; error_log("ℹ️ AI Post Generator: Using first administrator ID: {$post_author_id}"); } } }
            if ( $post_author_id === 0 ) { error_log("❌ AI Post Generator: CRITICAL - Could not determine valid author ID."); if (is_admin()) add_settings_error('ai-post-generator', 'author-critical-failure', esc_html__('Could not determine valid author. Set default author.', self::TEXT_DOMAIN), 'error'); return new WP_Error('author_critical_failure', esc_html__('Could not determine valid author.', self::TEXT_DOMAIN)); }

            $keyword_from_input = trim($initial_keyword_or_search_query); $original_input_keyword_log = $keyword_from_input; $generation_context_hint_for_ai = ''; $category_name_source_for_logic = '';
            $is_manual_process_for_cat_assign = ($category_id_from_manual_selection !== -1);

            $term_object_for_hint = null;
            if ($is_manual_process_for_cat_assign && $category_id_from_manual_selection > 0) { $term_object_for_hint = get_term( $category_id_from_manual_selection, 'category' ); if ($term_object_for_hint && !is_wp_error($term_object_for_hint)) { error_log("ℹ️ AI Post Generator (Manual): Using manually selected category ID {$category_id_from_manual_selection} for content context hint."); } else { error_log("⚠️ AI Post Generator (Manual): Manually selected category ID {$category_id_from_manual_selection} invalid. Hint based on auto/default."); $term_object_for_hint = null; } }
            if (!$term_object_for_hint) {
                $temp_cat_id_for_auto_hint = 0;
                if (!$is_manual_process_for_cat_assign) { $temp_cat_id_for_auto_hint = (int) get_option( self::OPTION_AUTO_GEN_TARGET_CATEGORY, 0 ); if ($temp_cat_id_for_auto_hint > 0) { error_log("ℹ️ AI Post Generator (Auto-Gen): Attempting to use target category ID {$temp_cat_id_for_auto_hint} from settings for hint."); } }
                if (empty($temp_cat_id_for_auto_hint) && !empty($keyword_from_input)) { $category_mappings = get_option( self::OPTION_CATEGORY_MAPPINGS, [] ); if (!empty($category_mappings)) { $input_keyword_lower = strtolower($keyword_from_input); foreach ( $category_mappings as $mapping ) { if ( ! empty( $mapping['keyword'] ) && ! empty( $mapping['category_id'] ) ) { if ( stripos( $input_keyword_lower, strtolower($mapping['keyword']) ) !== false ) { $temp_cat_id_for_auto_hint = (int) $mapping['category_id']; error_log("ℹ️ AI Post Generator: Keyword '{$keyword_from_input}' mapped to category ID {$temp_cat_id_for_auto_hint} for hint."); break; } } } } }
                if ($temp_cat_id_for_auto_hint > 0) { $term_object_for_hint = get_term( $temp_cat_id_for_auto_hint, 'category' ); if (!$term_object_for_hint || is_wp_error($term_object_for_hint)) { error_log("⚠️ AI Post Generator: Category ID {$temp_cat_id_for_auto_hint} for hint is invalid."); $term_object_for_hint = null;} }
            }
            if ($term_object_for_hint && !is_wp_error($term_object_for_hint)) { $category_name_source_for_logic = $term_object_for_hint->name; if (property_exists($term_object_for_hint, 'slug') && preg_match('/^[a-zA-Z0-9-]+$/', $term_object_for_hint->slug)) { $generation_context_hint_for_ai = str_replace('-', ' ', $term_object_for_hint->slug); } else { $temp_hint = strtolower(sanitize_text_field($term_object_for_hint->name)); if (preg_match('/[a-zA-Z]/', $temp_hint)) { $generation_context_hint_for_ai = $temp_hint; } else if (!empty($temp_hint)) { error_log("⚠️ AI Post Generator: Context hint '{$temp_hint}' from category '{$category_name_source_for_logic}' not suitable English hint."); } } $generation_context_hint_for_ai = trim(str_ireplace(array('分类', '默认', 'category', 'default', 'uncategorized'), '', $generation_context_hint_for_ai)); $generation_context_hint_for_ai = trim(preg_replace('/\s+/', ' ', $generation_context_hint_for_ai)); if (!empty($generation_context_hint_for_ai)) { error_log("ℹ️ AI Post Generator: Final AI content context hint: '{$generation_context_hint_for_ai}'. Original category name: '{$category_name_source_for_logic}'"); }
            } else { error_log("ℹ️ AI Post Generator: No valid category term object for content context hint. Hint will be empty."); }

            $final_subject_for_ai_prompt = $keyword_from_input; $use_search_research = get_option( self::OPTION_ENABLE_SEARCH_KEYWORD_RESEARCH, false );
            if ( $use_search_research && !empty($keyword_from_input) ) { error_log("ℹ️ AI Post Generator: Keyword research ENABLED. Query: '{$keyword_from_input}', AI Context: '{$generation_context_hint_for_ai}'"); $refined_english_keyword_string = $this->_get_refined_keywords_via_search_research( $keyword_from_input, $generation_context_hint_for_ai ); if ( $refined_english_keyword_string !== false && !empty(trim($refined_english_keyword_string)) ) { $final_subject_for_ai_prompt = $refined_english_keyword_string; error_log("ℹ️ AI Post Generator: Using refined English keywords for prompts: '{$final_subject_for_ai_prompt}'"); } else { error_log("ℹ️ AI Post Generator: Keyword research failed or no English results. Using original input or category context."); } }
            elseif (empty($keyword_from_input)) { error_log("ℹ️ AI Post Generator: No initial keyword provided."); if (!empty($generation_context_hint_for_ai) && preg_match('/[a-zA-Z]/', $generation_context_hint_for_ai)) { $final_subject_for_ai_prompt = $generation_context_hint_for_ai; error_log("ℹ️ AI Post Generator: No input keyword, using English context hint '{$final_subject_for_ai_prompt}' as primary subject."); } else { $final_subject_for_ai_prompt = ''; error_log("ℹ️ AI Post Generator: No input keyword and no suitable English context hint. Subject for prompts empty."); } }

            $content_max_tokens = get_option(self::OPTION_MAX_TOKENS_AUTO, self::DEFAULT_MAX_TOKENS); if ($manual_max_tokens !== null && absint($manual_max_tokens) >= 100) { $content_max_tokens = absint($manual_max_tokens); } if ($content_max_tokens < 100) $content_max_tokens = 100; if ($content_max_tokens > 8000) $content_max_tokens = 8000;

            $title = ''; $max_attempts = 3; $attempts = 0; $unique_title_found = false;
            while ( $attempts < $max_attempts && ! $unique_title_found ) {
                $attempts++; $log_subject_display = !empty($final_subject_for_ai_prompt) ? $final_subject_for_ai_prompt : "(relying on category context)"; error_log("ℹ️ AI Post Generator: Attempt #{$attempts} to generate English title. Base Subject: '{$log_subject_display}', Category Name: '{$category_name_source_for_logic}', AI Context Hint: '{$generation_context_hint_for_ai}'.");
                if (empty($final_subject_for_ai_prompt) && empty($generation_context_hint_for_ai)) { error_log("⚠️ AI Post Generator: Cannot generate title. No subject/context."); if ( is_admin() ) add_settings_error('ai-post-generator', 'title_gen_no_subject_context_en', esc_html__('Cannot generate title: No keywords or category context provided.', self::TEXT_DOMAIN), 'error'); return new WP_Error('title_gen_no_subject_context_en', esc_html__('Cannot generate title: No keywords or category context.', self::TEXT_DOMAIN)); }
                $title_prompt = "Generate a concise, engaging, and SEO-friendly blog post title in English. "; $is_review_category = false;
                if (!empty($category_name_source_for_logic)) { $review_keywords = ['review', 'reviews', '评论', '评测', 'recensioni', 'bewertungen', 'critiques', 'reseñas', 'tool review', 'software review', 'platform review', 'product review', 'evaluation', 'critique', 'assessment']; foreach ($review_keywords as $rk) { if (stripos($category_name_source_for_logic, $rk) !== false || stripos($generation_context_hint_for_ai, $rk) !== false) { $is_review_category = true; break; } } }
                if ($is_review_category) { $title_prompt .= "The category is for 'Reviews' (e.g., '{$generation_context_hint_for_ai}'). Title should be a review of a specific, well-known product, service, tool, platform, book, movie, or similar entity. You MUST CHOOSE a single, popular, real entity (e.g., a software like 'Slack', a book, a movie, an online service - pick one appropriate to user's input or general knowledge if input is broad). Title MUST be structured as a review of that chosen entity. Example: if base keyword is 'Productivity Software' and category 'Software Reviews', a good title: \"Slack Communication Platform Review: Boosting Team Collaboration in " . date('Y') . "?\". "; if (!empty($final_subject_for_ai_prompt) && $final_subject_for_ai_prompt !== $generation_context_hint_for_ai && $final_subject_for_ai_prompt !== $keyword_from_input) { $title_prompt .= "Incorporate these keywords if relevant: '{$final_subject_for_ai_prompt}'. "; } elseif (!empty($keyword_from_input) && $keyword_from_input !== $generation_context_hint_for_ai) { $title_prompt .= "Initial user keyword was '{$keyword_from_input}'. If it names a specific entity, prioritize reviewing it. Otherwise, choose another popular one. "; } }
                elseif (!empty($generation_context_hint_for_ai) && preg_match('/[a-zA-Z]/', $generation_context_hint_for_ai) ) { $title_prompt .= "The title should be about the topic: '" . esc_attr( $generation_context_hint_for_ai ) . "'. "; if (!empty($final_subject_for_ai_prompt)) { $title_prompt .= "Incorporate or base on keywords/subject: '" . esc_attr( $final_subject_for_ai_prompt ) . "'. "; } }
                elseif (!empty($final_subject_for_ai_prompt)) { $title_prompt .= "Base title on keywords/subject: '" . esc_attr( $final_subject_for_ai_prompt ) . "'. "; }
                else { $title_prompt .= "Title should be about a popular, engaging online topic. "; } $title_prompt .= "Enclose main title phrase in double quotes. Ensure uniqueness. Must be in English for a blog post.";
                $raw_ai_title_output = $this->generate_ai_title( $title_prompt );
                if ( ! $raw_ai_title_output ) { error_log( "❌ AI Post Generator: Failed raw title gen attempt {$attempts}." ); if ($attempts === $max_attempts) { if (is_admin()) add_settings_error('ai-post-generator', 'title_gen_fail_en_final', esc_html__('Failed to generate English title.', self::TEXT_DOMAIN), 'error'); return new WP_Error( 'title_generation_failed_en_final', esc_html__( 'Failed to generate English title.', self::TEXT_DOMAIN ) ); } usleep(rand(500000,1000000)); continue; }
                $title = $this->extract_quoted_title( $raw_ai_title_output );
                if (empty($title) || str_word_count($title) < 2 || !preg_match('/[a-zA-Z]/', $title) ) { error_log( "❌ AI Post Generator: Invalid/non-English title '{$title}' attempt {$attempts}. Raw: " . esc_html($raw_ai_title_output) ); if ($attempts === $max_attempts) { if (is_admin()) add_settings_error('ai-post-generator', 'title_extract_fail_en_final', esc_html__('Failed to extract valid English title.', self::TEXT_DOMAIN), 'error'); return new WP_Error( 'title_extraction_failed_en_final', esc_html__( 'Failed to extract valid English title.', self::TEXT_DOMAIN ) ); } usleep(rand(500000,1000000)); continue; }
                global $wpdb; $clean_title_for_check = wp_strip_all_tags($title); $post_exists = $wpdb->get_var( $wpdb->prepare( "SELECT ID FROM $wpdb->posts WHERE post_title = %s AND post_type = 'post' AND post_status IN ('publish', 'draft', 'pending', 'future', 'private')", $clean_title_for_check ) );
                if ( $post_exists ) { error_log( "⚠️ AI Post Generator: Duplicate title '{$clean_title_for_check}'. Regenerating..." ); if ($attempts === $max_attempts) { if (is_admin()) add_settings_error( 'ai-post-generator', 'duplicate_title_failed_en_final', esc_html__( 'Failed to generate unique English title.', self::TEXT_DOMAIN ), 'error' ); return new WP_Error( 'duplicate_title_failed_en_final', esc_html__( 'Failed to generate unique English title.', self::TEXT_DOMAIN ) ); } usleep(rand(500000,1000000)); } else { $unique_title_found = true; }
            }
            if ( ! $unique_title_found ) { if ( is_admin() ) add_settings_error( 'ai-post-generator', 'no-unique-title_en_final', esc_html__( 'Could not generate unique English title.', self::TEXT_DOMAIN ), 'error' ); return new WP_Error( 'no_unique_title_en_final', esc_html__( 'Could not generate unique English title.', self::TEXT_DOMAIN ) );}

            $content_subject_for_prompt = !empty($final_subject_for_ai_prompt) ? $final_subject_for_ai_prompt : $title; if (empty($content_subject_for_prompt) && !empty($generation_context_hint_for_ai) && preg_match('/[a-zA-Z]/', $generation_context_hint_for_ai)) { $content_subject_for_prompt = $generation_context_hint_for_ai; } if (empty($content_subject_for_prompt)) { if ( is_admin() ) add_settings_error('ai-post-generator', 'content_gen_no_subject_en_final', esc_html__('Cannot generate content: No subject/title.', self::TEXT_DOMAIN), 'error'); return new WP_Error('content_gen_no_subject_en_final', esc_html__('Cannot generate content: No subject/title.', self::TEXT_DOMAIN));}
            $approx_word_count = round($content_max_tokens * 0.6); $content_prompt = "Write a comprehensive, engaging, SEO-friendly blog post in English, titled \"{$title}\". Primary subject: '{$content_subject_for_prompt}'. ";
            if ($is_review_category) { $content_prompt .= "This post is a review of the entity in the title. Discuss its features, pros/cons, pricing, UX, target audience. Provide a balanced view. "; }
            elseif (!empty($generation_context_hint_for_ai) && preg_match('/[a-zA-Z]/', $generation_context_hint_for_ai)) { $content_prompt .= "Content should focus on '{$generation_context_hint_for_ai}'. E.g., if 'digital marketing trends', discuss emerging strategies, new platforms, actionable insights. "; }
            else { $content_prompt .= "Cover how-to guides, explanations, benefits, comparisons, or case studies for '{$content_subject_for_prompt}'. "; } $content_prompt .= "Structure: 1. Captivating intro stating purpose. 2. Well-developed body paragraphs with examples/lists. 3. Concise conclusion. Aim for {$approx_word_count} words, original, logical. Professional, accessible tone. No HTML. Entire post in English.";
            $content = $this->generate_ai_text( $content_prompt, true, $content_max_tokens, 'content' );
            if ( ! $content ) { if ( is_admin() ) add_settings_error('ai-post-generator', 'content_generation_failed_en_final', sprintf(esc_html__( 'Failed to generate English content for subject %s.', self::TEXT_DOMAIN ), esc_html($content_subject_for_prompt) ), 'error'); return new WP_Error( 'content_generation_failed_en_final', esc_html__( 'Failed to generate English content.', self::TEXT_DOMAIN )) ;}
            $content = wpautop(preg_replace('/^\s*["\']?(.*?)["\']?\s*$/s', '$1', trim($content)));

            $tags_to_assign = []; $tags_prompt = "Generate 5-8 relevant, comma-separated, SEO-friendly tags in English for a blog post titled '" . esc_attr( $title ) . "' about '{$content_subject_for_prompt}'. ";
            if ($is_review_category && stripos(strtolower($title), 'review') !== false) { preg_match('/^([\w\s.&]+?) (Review|Reviews)/i', $title, $entity_match); if (!empty($entity_match[1])) { $tags_prompt .= "Include '{$entity_match[1]}' as a tag, and general review tags. "; } else { $tags_prompt .= "Include reviewed entity name from title as tag, and general review tags. "; } }
            elseif (!empty($generation_context_hint_for_ai) && preg_match('/[a-zA-Z]/', $generation_context_hint_for_ai)) { $tags_prompt .= "Tags particularly relevant to '{$generation_context_hint_for_ai}'. "; } $tags_prompt .= "Tags: concise, lowercase, multi-word phrases ok. Examples: 'digital tools, productivity app, content strategy, online marketing, software review'. No other text/numbers/quotes. All tags in English.";
            $generated_tags = $this->generate_ai_tags( $tags_prompt );
            if ( is_array( $generated_tags ) && ! empty( $generated_tags ) ) { $tags_to_assign = array_slice($generated_tags, 0, 8); error_log( "✅ AI Post Generator: Generated English tags: " . implode(', ', $tags_to_assign) ); } else { error_log( "ℹ️ AI Post Generator: Failed to generate English tags or none returned." ); }

            $post_data = ['post_title' => wp_strip_all_tags( $title ), 'post_content' => $content, 'post_status' => 'publish', 'post_type' => 'post', 'post_author' => $post_author_id, 'post_category' => []];
            $final_assigned_category_id = 0;
            if ($is_manual_process_for_cat_assign && $category_id_from_manual_selection > 0 ) { if (term_exists((int)$category_id_from_manual_selection, 'category')) { $final_assigned_category_id = (int)$category_id_from_manual_selection; error_log("ℹ️ AI Post Generator (Manual): Using user-selected category ID for publishing: {$final_assigned_category_id}"); } else { error_log("⚠️ AI Post Generator (Manual): User-selected category ID {$category_id_from_manual_selection} is invalid. Will try auto-identify."); } }
            if ($final_assigned_category_id === 0) {
                if (!$is_manual_process_for_cat_assign) { $auto_gen_target_category_id = (int) get_option( self::OPTION_AUTO_GEN_TARGET_CATEGORY, 0 ); if ($auto_gen_target_category_id > 0 && term_exists($auto_gen_target_category_id, 'category')) { $final_assigned_category_id = $auto_gen_target_category_id; error_log("ℹ️ AI Post Generator (Cron): Using specific target category ID from settings: {$final_assigned_category_id}"); } else { if ($auto_gen_target_category_id > 0) error_log("⚠️ AI Post Generator (Cron): Auto-gen target category ID {$auto_gen_target_category_id} is invalid."); } }
            }
            if ($final_assigned_category_id === 0) {
                error_log("ℹ️ AI Post Generator: No specific category chosen. Attempting auto-identify by title or mappings."); $all_categories = get_categories(array('hide_empty' => false, 'fields' => 'id=>name')); $best_match_category_id = 0; $longest_match_length = 0;
                if (!empty($title) && !empty($all_categories)) { $title_lower = strtolower($title); foreach ($all_categories as $cat_id => $cat_name) { $cat_name_lower = strtolower($cat_name); if (empty($cat_name_lower)) continue; if (stripos($title_lower, $cat_name_lower) !== false) { if (strlen($cat_name_lower) > $longest_match_length) { $longest_match_length = strlen($cat_name_lower); $best_match_category_id = (int)$cat_id; } } } }
                if ($best_match_category_id > 0) { $final_assigned_category_id = $best_match_category_id; error_log("ℹ️ AI Post Generator (Auto-Identify): Matched title to category ID: {$final_assigned_category_id} ('" . ($all_categories[$final_assigned_category_id] ?? 'Unknown') . "')"); }
                else { error_log("ℹ️ AI Post Generator (Auto-Identify Failed): No title match. Trying mappings with subject: '{$final_subject_for_ai_prompt}'."); if (!empty($final_subject_for_ai_prompt)) { $category_mappings = get_option( self::OPTION_CATEGORY_MAPPINGS, [] ); if (!empty($category_mappings)) { $subject_lower = strtolower($final_subject_for_ai_prompt); $title_lower_for_map = strtolower($post_data['post_title']); foreach ( $category_mappings as $mapping ) { if ( ! empty( $mapping['keyword'] ) && ! empty( $mapping['category_id'] ) ) { $map_keyword_lower = strtolower($mapping['keyword']); if ( stripos( $title_lower_for_map, $map_keyword_lower ) !== false || stripos( $subject_lower, $map_keyword_lower ) !== false ) { if (term_exists((int)$mapping['category_id'], 'category')) { $final_assigned_category_id = (int) $mapping['category_id']; error_log("ℹ️ AI Post Generator (Mapping Fallback): Assigned category ID {$final_assigned_category_id} via mapping '{$mapping['keyword']}'."); break; } } } } } } }
            }
            if ( $final_assigned_category_id > 0 ) { $post_data['post_category'][] = $final_assigned_category_id; }
            else { $wp_default_cat = get_option( 'default_category' ); if ( $wp_default_cat && term_exists((int)$wp_default_cat, 'category') ) { $post_data['post_category'][] = (int) $wp_default_cat; error_log("ℹ️ AI Post Generator (WP Default Fallback): Using WordPress default category ID: {$wp_default_cat}"); } else { error_log("⚠️ AI Post Generator: No category assigned, WP default category invalid or not set. Post will be Uncategorized."); } }

            $post_id = wp_insert_post( $post_data, true );
            if ( is_wp_error( $post_id ) ) { if ( is_admin() ) add_settings_error('ai-post-generator', 'post_insert_error_en', sprintf( esc_html__( 'Failed to create English post: %s', self::TEXT_DOMAIN ), $post_id->get_error_message()), 'error'); return $post_id;}
            error_log( "✅ AI Post Generator: English post created: ID {$post_id}, Title '{$title}'" );
            if ( ! empty( $tags_to_assign ) ) { wp_set_post_tags( $post_id, $tags_to_assign, false ); error_log( "✅ AI Post Generator: English tags set for post ID {$post_id}." ); }
            $current_content_for_linking = get_post_field('post_content', $post_id); $updated_content_with_links = $this->insert_internal_links( $current_content_for_linking, $post_id, $tags_to_assign );
            if ($updated_content_with_links !== $current_content_for_linking) { wp_update_post( [ 'ID' => $post_id, 'post_content' => $updated_content_with_links ] ); error_log( "✅ AI Post Generator: Internal links processed for post ID {$post_id}." ); }
            $this->set_random_featured_image( $post_id );
            $success_message = sprintf( esc_html__( 'English Post "%1$s" (ID: %5$d) successfully generated using %4$s! %2$sView Post%3$s', self::TEXT_DOMAIN ), esc_html( $title ), '<a href="' . esc_url( get_permalink( $post_id ) ) . '" target="_blank">', '</a>', strtoupper($active_provider), $post_id );
            $details = []; if ($is_review_category && stripos(strtolower($title), 'review') !== false) { preg_match('/^([\w\s.&]+?) (Review|Reviews)/i', $title, $entity_match_msg); $details[] = sprintf(esc_html__('Content focuses on a review of "%1$s" due to category "%2$s".', self::TEXT_DOMAIN), (!empty($entity_match_msg[1]) ? esc_html(trim($entity_match_msg[1])) : 'selected entity'), esc_html($category_name_source_for_logic)); }
            if ($use_search_research && $final_subject_for_ai_prompt !== $original_input_keyword_log && !empty($original_input_keyword_log)) { $details[] = sprintf(esc_html__('Based on initial keyword "%1$s", refined to "%2$s".', self::TEXT_DOMAIN), esc_html($original_input_keyword_log), esc_html($final_subject_for_ai_prompt)); }
            elseif (!empty($generation_context_hint_for_ai) && $final_subject_for_ai_prompt === $generation_context_hint_for_ai && empty($original_input_keyword_log) ) { $details[] = sprintf(esc_html__('Generated based on category context: "%s".', self::TEXT_DOMAIN), esc_html($generation_context_hint_for_ai)); }
            elseif (!empty($final_subject_for_ai_prompt)) { $details[] = sprintf(esc_html__('Primary subject for generation was: "%s".', self::TEXT_DOMAIN), esc_html($final_subject_for_ai_prompt)); }
            if (!empty($details)) $success_message .= '<br/>' . implode(' ', $details);
            if ( is_admin() ) { add_settings_error( 'ai-post-generator', 'post-success_en', $success_message, 'success' ); }
            return $post_id;
        }

        public function do_cron_job() {
             if ( get_option( self::OPTION_ENABLED, false ) ) { $active_provider = get_option( self::OPTION_ACTIVE_AI_PROVIDER, 'cohere' ); error_log( "ℹ️ AI Post Generator Cron: Job started using {$active_provider}." ); $cron_keyword = get_option( self::OPTION_CRON_KEYWORD, '' ); $result = $this->generate_and_publish_post( $cron_keyword, -1, null ); if ( is_wp_error( $result ) ) error_log( "❌ AI Post Generator Cron Error ({$active_provider}): " . $result->get_error_message() ); else error_log( "✅ AI Post Generator Cron ({$active_provider}): English post successfully generated. Post ID: " . $result ); }
             else { error_log( "ℹ️ AI Post Generator Cron: Automatic generation is currently disabled. Job skipped." ); }
        }

        public function settings_init() {
            register_setting( 'ai-post-generator-api-settings', self::OPTION_COHERE_API_KEY, 'sanitize_text_field' ); register_setting( 'ai-post-generator-api-settings', self::OPTION_OPENAI_API_KEY, 'sanitize_text_field' ); register_setting( 'ai-post-generator-api-settings', self::OPTION_OPENAI_MODEL, 'sanitize_text_field' ); register_setting( 'ai-post-generator-api-settings', self::OPTION_GEMINI_API_KEY, 'sanitize_text_field' ); register_setting( 'ai-post-generator-api-settings', self::OPTION_GEMINI_MODEL, 'sanitize_text_field' ); register_setting( 'ai-post-generator-api-settings', self::OPTION_ACTIVE_AI_PROVIDER, 'sanitize_text_field' );
            register_setting( 'ai-post-generator-search-settings', self::OPTION_ENABLE_SEARCH_KEYWORD_RESEARCH, ['type' => 'boolean', 'sanitize_callback' => array($this, 'sanitize_checkbox')] ); register_setting( 'ai-post-generator-search-settings', self::OPTION_GOOGLE_CSE_API_KEY, 'sanitize_text_field' ); register_setting( 'ai-post-generator-search-settings', self::OPTION_GOOGLE_CSE_CX_ID, 'sanitize_text_field' ); register_setting( 'ai-post-generator-search-settings', self::OPTION_SEARCH_RESULTS_TO_CONSIDER, ['type' => 'integer', 'sanitize_callback' => 'absint', 'default' => self::DEFAULT_SEARCH_RESULTS_TO_CONSIDER] );
            register_setting( 'ai-post-generator-auto-gen-settings', self::OPTION_ENABLED, ['type' => 'boolean', 'sanitize_callback' => array($this, 'sanitize_checkbox')] ); register_setting( 'ai-post-generator-auto-gen-settings', self::OPTION_INTERVAL, 'sanitize_text_field' ); register_setting( 'ai-post-generator-auto-gen-settings', self::OPTION_CRON_KEYWORD, 'sanitize_text_field' ); register_setting( 'ai-post-generator-auto-gen-settings', self::OPTION_AUTO_GEN_TARGET_CATEGORY, 'absint' ); register_setting( 'ai-post-generator-auto-gen-settings', self::OPTION_DEFAULT_AUTHOR, 'absint' ); register_setting( 'ai-post-generator-auto-gen-settings', self::OPTION_CATEGORY_MAPPINGS, array($this, 'sanitize_category_mappings') ); register_setting( 'ai-post-generator-auto-gen-settings', self::OPTION_MAX_TOKENS_AUTO, ['type' => 'integer', 'sanitize_callback' => 'absint', 'default' => self::DEFAULT_MAX_TOKENS] );
        }
        public function sanitize_checkbox($input){ return isset($input) && $input == '1'; }
        public function sanitize_category_mappings($mappings_input) { $sanitized_mappings = []; if (!is_array($mappings_input)) { return $sanitized_mappings; } $keywords_array = $mappings_input['category_mappings_keyword'] ?? ($mappings_input['keyword'] ?? null); $categories_array = $mappings_input['category_mappings_category_id'] ?? ($mappings_input['category_id'] ?? null); if (is_array($keywords_array) && is_array($categories_array)) { foreach ($keywords_array as $index => $keyword) { if (!empty($keyword) && isset($categories_array[$index]) && !empty($categories_array[$index])) { $sanitized_mappings[] = ['keyword' => sanitize_text_field(trim($keyword)), 'category_id' => absint($categories_array[$index])]; } } } elseif (is_array($mappings_input) && (!isset($mappings_input['keyword']) && !isset($mappings_input['category_mappings_keyword']))) { foreach ($mappings_input as $map_item) { if (is_array($map_item) && isset($map_item['keyword']) && !empty($map_item['keyword']) && isset($map_item['category_id']) && !empty($map_item['category_id'])) { $sanitized_mappings[] = ['keyword' => sanitize_text_field(trim($map_item['keyword'])), 'category_id' => absint($map_item['category_id'])]; } } } return $sanitized_mappings; }
        public function add_admin_menu() { add_menu_page(esc_html__( 'AI Post Generator', self::TEXT_DOMAIN ), esc_html__( 'AI Posts', self::TEXT_DOMAIN ), 'manage_options', 'ai-post-generator', array( $this, 'render_settings_page' ), 'dashicons-superhero', 80 ); }
        public function handle_api_settings_submission() { check_admin_referer('ai_post_generator_save_api_settings_nonce', 'ai_post_generator_api_settings_nonce_field'); if (!current_user_can('manage_options')) wp_die(esc_html__('No permission.', self::TEXT_DOMAIN)); if (isset($_POST[self::OPTION_COHERE_API_KEY])) update_option(self::OPTION_COHERE_API_KEY, sanitize_text_field($_POST[self::OPTION_COHERE_API_KEY]));  if (isset($_POST[self::OPTION_OPENAI_API_KEY])) update_option(self::OPTION_OPENAI_API_KEY, sanitize_text_field($_POST[self::OPTION_OPENAI_API_KEY])); if (isset($_POST[self::OPTION_GEMINI_API_KEY])) update_option(self::OPTION_GEMINI_API_KEY, sanitize_text_field($_POST[self::OPTION_GEMINI_API_KEY])); $openai_model = isset($_POST[self::OPTION_OPENAI_MODEL]) ? sanitize_text_field($_POST[self::OPTION_OPENAI_MODEL]) : 'gpt-3.5-turbo'; update_option(self::OPTION_OPENAI_MODEL, !empty($openai_model) ? $openai_model : 'gpt-3.5-turbo'); $gemini_model = isset($_POST[self::OPTION_GEMINI_MODEL]) ? sanitize_text_field($_POST[self::OPTION_GEMINI_MODEL]) : self::DEFAULT_GEMINI_MODEL; update_option(self::OPTION_GEMINI_MODEL, !empty($gemini_model) ? $gemini_model : self::DEFAULT_GEMINI_MODEL); if (isset($_POST[self::OPTION_ACTIVE_AI_PROVIDER])) update_option(self::OPTION_ACTIVE_AI_PROVIDER, sanitize_text_field($_POST[self::OPTION_ACTIVE_AI_PROVIDER])); add_settings_error('ai-post-generator', 'api_settings_saved', esc_html__('AI Provider settings saved.', self::TEXT_DOMAIN), 'success'); set_transient('settings_errors_aipg', get_settings_errors(), 30); wp_redirect(admin_url('admin.php?page=ai-post-generator#api-settings')); exit; }
        public function handle_search_settings_submission() { check_admin_referer('ai_post_generator_save_search_settings_nonce', 'ai_post_generator_search_settings_nonce_field'); if (!current_user_can('manage_options')) wp_die(esc_html__('No permission.', self::TEXT_DOMAIN)); $enable_search = isset($_POST[self::OPTION_ENABLE_SEARCH_KEYWORD_RESEARCH]) && $_POST[self::OPTION_ENABLE_SEARCH_KEYWORD_RESEARCH] === '1'; update_option(self::OPTION_ENABLE_SEARCH_KEYWORD_RESEARCH, $enable_search); if (isset($_POST[self::OPTION_GOOGLE_CSE_API_KEY])) update_option(self::OPTION_GOOGLE_CSE_API_KEY, sanitize_text_field($_POST[self::OPTION_GOOGLE_CSE_API_KEY])); if (isset($_POST[self::OPTION_GOOGLE_CSE_CX_ID])) update_option(self::OPTION_GOOGLE_CSE_CX_ID, sanitize_text_field($_POST[self::OPTION_GOOGLE_CSE_CX_ID])); if (isset($_POST[self::OPTION_SEARCH_RESULTS_TO_CONSIDER])) { $num_results = absint($_POST[self::OPTION_SEARCH_RESULTS_TO_CONSIDER]); update_option(self::OPTION_SEARCH_RESULTS_TO_CONSIDER, ($num_results > 0 && $num_results <=10) ? $num_results : self::DEFAULT_SEARCH_RESULTS_TO_CONSIDER); } add_settings_error('ai-post-generator', 'search_settings_saved', esc_html__('Search Research settings saved.', self::TEXT_DOMAIN), 'success'); set_transient('settings_errors_aipg', get_settings_errors(), 30); wp_redirect(admin_url('admin.php?page=ai-post-generator#search-engine-research')); exit; }
        public function handle_auto_gen_settings_submission() {
            check_admin_referer('ai_post_generator_save_auto_gen_settings_nonce', 'ai_post_generator_auto_gen_settings_nonce_field'); if (!current_user_can('manage_options')) wp_die(esc_html__('No permission.', self::TEXT_DOMAIN));
            $old_interval = get_option(self::OPTION_INTERVAL, 'daily'); $new_interval = isset($_POST[self::OPTION_INTERVAL]) ? sanitize_text_field($_POST[self::OPTION_INTERVAL]) : $old_interval; if (empty($new_interval) || !array_key_exists($new_interval, wp_get_schedules())) $new_interval = 'daily';
            update_option(self::OPTION_INTERVAL, $new_interval); update_option(self::OPTION_CRON_KEYWORD, isset($_POST[self::OPTION_CRON_KEYWORD]) ? sanitize_text_field($_POST[self::OPTION_CRON_KEYWORD]) : '');
            update_option(self::OPTION_AUTO_GEN_TARGET_CATEGORY, isset($_POST[self::OPTION_AUTO_GEN_TARGET_CATEGORY]) ? absint($_POST[self::OPTION_AUTO_GEN_TARGET_CATEGORY]) : 0);
            update_option(self::OPTION_DEFAULT_AUTHOR, isset($_POST[self::OPTION_DEFAULT_AUTHOR]) ? absint($_POST[self::OPTION_DEFAULT_AUTHOR]) : 0);
            if (isset($_POST[self::OPTION_MAX_TOKENS_AUTO])) { $max_tokens = absint($_POST[self::OPTION_MAX_TOKENS_AUTO]); if ($max_tokens < 100) $max_tokens = 100; if ($max_tokens > 8000) $max_tokens = 8000; update_option(self::OPTION_MAX_TOKENS_AUTO, $max_tokens); } else { update_option(self::OPTION_MAX_TOKENS_AUTO, self::DEFAULT_MAX_TOKENS); }
            $raw_mappings = []; if ( isset( $_POST['category_mappings_keyword'] ) && is_array( $_POST['category_mappings_keyword'] ) ) { foreach ( $_POST['category_mappings_keyword'] as $index => $keyword ) { if ( ! empty( $keyword ) && isset( $_POST['category_mappings_category_id'][ $index ] ) && !empty($_POST['category_mappings_category_id'][ $index ]) ) { $raw_mappings[] = ['keyword' => $keyword, 'category_id' => $_POST['category_mappings_category_id'][ $index ]]; } } }
            update_option(self::OPTION_CATEGORY_MAPPINGS, $this->sanitize_category_mappings($raw_mappings));
            $new_cron_enabled_status = isset($_POST[self::OPTION_ENABLED]) && $_POST[self::OPTION_ENABLED] === '1'; $old_cron_enabled_status = get_option(self::OPTION_ENABLED, false); update_option(self::OPTION_ENABLED, $new_cron_enabled_status);
            if ($new_cron_enabled_status) { if (!$old_cron_enabled_status || ($new_interval !== $old_interval) || !wp_next_scheduled(self::CRON_EVENT_HOOK)) { wp_clear_scheduled_hook(self::CRON_EVENT_HOOK); wp_schedule_event(time(), $new_interval, self::CRON_EVENT_HOOK); add_settings_error('ai-post-generator', 'cron_started', esc_html__('Auto-gen (re)scheduled.', self::TEXT_DOMAIN), 'success'); } }
            else { if ($old_cron_enabled_status || wp_next_scheduled(self::CRON_EVENT_HOOK)) { wp_clear_scheduled_hook(self::CRON_EVENT_HOOK); add_settings_error('ai-post-generator', 'cron_stopped', esc_html__('Auto-gen stopped.', self::TEXT_DOMAIN), 'success'); } }
            add_settings_error('ai-post-generator', 'auto_gen_settings_saved', esc_html__('Auto-gen settings saved.', self::TEXT_DOMAIN), 'success'); set_transient('settings_errors_aipg', get_settings_errors(), 30); wp_redirect(admin_url('admin.php?page=ai-post-generator#automatic-generation')); exit;
        }
        public function handle_manual_generation_submission() { check_admin_referer('ai_post_generator_generate_now_nonce', 'ai_post_generator_manual_nonce_field'); if (!current_user_can('manage_options')) wp_die(esc_html__('No permission.', self::TEXT_DOMAIN)); $manual_keyword = isset($_POST['manual_keyword']) ? sanitize_text_field($_POST['manual_keyword']) : ''; $manual_category_id = isset($_POST['manual_category_id']) ? absint($_POST['manual_category_id']) : 0; $max_tokens_for_manual = null; if (isset($_POST['manual_max_tokens_input']) && trim($_POST['manual_max_tokens_input']) !== '') { $input_tokens = absint($_POST['manual_max_tokens_input']); if ($input_tokens >= 100) { $max_tokens_for_manual = min(8000, max(100, $input_tokens)); } } $this->generate_and_publish_post($manual_keyword, $manual_category_id, $max_tokens_for_manual); set_transient('settings_errors_aipg', get_settings_errors(), 30); wp_redirect(admin_url('admin.php?page=ai-post-generator#manual-generation')); exit; }
        public function render_settings_page() {
            $data = [
                'cohere_api_key' => get_option( self::OPTION_COHERE_API_KEY ), 'openai_api_key' => get_option( self::OPTION_OPENAI_API_KEY ), 'openai_model' => get_option( self::OPTION_OPENAI_MODEL, 'gpt-3.5-turbo' ), 'gemini_api_key' => get_option( self::OPTION_GEMINI_API_KEY ), 'gemini_model' => get_option( self::OPTION_GEMINI_MODEL, self::DEFAULT_GEMINI_MODEL ), 'active_provider' => get_option( self::OPTION_ACTIVE_AI_PROVIDER, 'cohere' ),
                'enable_search_research' => get_option( self::OPTION_ENABLE_SEARCH_KEYWORD_RESEARCH, false ), 'google_cse_api_key' => get_option( self::OPTION_GOOGLE_CSE_API_KEY, '' ), 'google_cse_cx_id' => get_option( self::OPTION_GOOGLE_CSE_CX_ID, '' ), 'search_results_to_consider' => get_option( self::OPTION_SEARCH_RESULTS_TO_CONSIDER, self::DEFAULT_SEARCH_RESULTS_TO_CONSIDER ),
                'current_interval' => get_option( self::OPTION_INTERVAL, 'daily' ), 'cron_keyword' => get_option( self::OPTION_CRON_KEYWORD, '' ), 'is_enabled' => get_option( self::OPTION_ENABLED, false ), 'next_scheduled' => wp_next_scheduled( self::CRON_EVENT_HOOK ),
                'auto_gen_target_category_id' => get_option( self::OPTION_AUTO_GEN_TARGET_CATEGORY, 0 ),
                'default_author_id' => get_option( self::OPTION_DEFAULT_AUTHOR, 0 ),
                'category_mappings' => get_option( self::OPTION_CATEGORY_MAPPINGS, array() ), 'max_tokens_auto' => get_option( self::OPTION_MAX_TOKENS_AUTO, self::DEFAULT_MAX_TOKENS ), 'categories' => get_categories( array( 'hide_empty' => 0, 'orderby' => 'name' ) ), 'users' => get_users( array( 'role__in' => array( 'administrator', 'editor', 'author' ), 'orderby' => 'display_name' ) ),
                'default_gemini_model_const' => self::DEFAULT_GEMINI_MODEL, 'text_domain_const' => self::TEXT_DOMAIN,
            ];
            extract($data); include_once dirname(AI_POST_GENERATOR_PLUGIN_FILE) . '/admin/views/settings-page.php';
        }
        public function add_cron_intervals( $schedules ) {
            $custom_intervals = ['twenty_seconds' => ['interval' => 20, 'display' => esc_html__( 'Every 20 Seconds', self::TEXT_DOMAIN )], 'two_minutes' => ['interval' => 120, 'display' => esc_html__( 'Every 2 Minutes', self::TEXT_DOMAIN )], 'five_minutes' => ['interval' => 300, 'display' => esc_html__( 'Every 5 Minutes', self::TEXT_DOMAIN )], 'ten_minutes' => ['interval' => 600, 'display' => esc_html__( 'Every 10 Minutes', self::TEXT_DOMAIN )], 'fifteen_minutes' => ['interval' => 900, 'display' => esc_html__( 'Every 15 Minutes', self::TEXT_DOMAIN )], 'thirty_minutes' => ['interval' => 1800,'display' => esc_html__( 'Every 30 Minutes', self::TEXT_DOMAIN )]];
            foreach($custom_intervals as $key => $value) { if(!isset($schedules[$key])) { $schedules[$key] = $value; } }
            if (!isset($schedules['hourly'])) { $schedules['hourly'] = ['interval' => HOUR_IN_SECONDS, 'display' => esc_html__('Once Hourly')]; } if (!isset($schedules['twicedaily'])) { $schedules['twicedaily'] = ['interval' => 12 * HOUR_IN_SECONDS, 'display' => esc_html__('Twice Daily')]; } if (!isset($schedules['daily'])) { $schedules['daily'] = ['interval' => DAY_IN_SECONDS, 'display' => esc_html__('Once Daily')]; } return $schedules;
        }
        public static function activate_static() { self::get_instance()->activate(); }
        public static function deactivate_static() { self::get_instance()->deactivate(); }
        public function activate() { if ( get_option( self::OPTION_ENABLED, false ) && !wp_next_scheduled( self::CRON_EVENT_HOOK ) ) { $interval = get_option( self::OPTION_INTERVAL, 'daily' ); $schedules = wp_get_schedules(); if (empty($interval) || !isset($schedules[$interval])) { $interval = 'daily'; } wp_schedule_event( time(), $interval, self::CRON_EVENT_HOOK ); } if (false === get_option(self::OPTION_ACTIVE_AI_PROVIDER)) update_option(self::OPTION_ACTIVE_AI_PROVIDER, 'cohere'); if (false === get_option(self::OPTION_OPENAI_MODEL)) update_option(self::OPTION_OPENAI_MODEL, 'gpt-3.5-turbo'); if (false === get_option(self::OPTION_GEMINI_MODEL)) update_option(self::OPTION_GEMINI_MODEL, self::DEFAULT_GEMINI_MODEL); if (false === get_option(self::OPTION_MAX_TOKENS_AUTO)) update_option(self::OPTION_MAX_TOKENS_AUTO, self::DEFAULT_MAX_TOKENS); if (false === get_option(self::OPTION_ENABLE_SEARCH_KEYWORD_RESEARCH)) update_option(self::OPTION_ENABLE_SEARCH_KEYWORD_RESEARCH, false); if (false === get_option(self::OPTION_SEARCH_RESULTS_TO_CONSIDER)) update_option(self::OPTION_SEARCH_RESULTS_TO_CONSIDER, self::DEFAULT_SEARCH_RESULTS_TO_CONSIDER); if (false === get_option(self::OPTION_AUTO_GEN_TARGET_CATEGORY)) update_option(self::OPTION_AUTO_GEN_TARGET_CATEGORY, 0); }
        public function deactivate() { wp_clear_scheduled_hook( self::CRON_EVENT_HOOK ); }
        public static function uninstall() {
            $options = [ self::OPTION_COHERE_API_KEY, self::OPTION_OPENAI_API_KEY, self::OPTION_OPENAI_MODEL, self::OPTION_GEMINI_API_KEY, self::OPTION_GEMINI_MODEL, self::OPTION_ACTIVE_AI_PROVIDER, self::OPTION_INTERVAL, self::OPTION_CRON_KEYWORD, self::OPTION_AUTO_GEN_TARGET_CATEGORY, self::OPTION_DEFAULT_AUTHOR, self::OPTION_CATEGORY_MAPPINGS, self::OPTION_ENABLED, self::OPTION_MAX_TOKENS_AUTO, self::OPTION_ENABLE_SEARCH_KEYWORD_RESEARCH, self::OPTION_GOOGLE_CSE_API_KEY, self::OPTION_GOOGLE_CSE_CX_ID, self::OPTION_SEARCH_RESULTS_TO_CONSIDER ];
            foreach ($options as $option) delete_option($option); wp_clear_scheduled_hook( self::CRON_EVENT_HOOK );
        }

    } // End class AI_Post_Generator_Plugin
} // End if class_exists check